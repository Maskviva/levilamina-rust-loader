use super::*;
use crate::error::{Error, Result};
use crate::rt;

impl Block {
    pub fn set(&self, spec: &str) -> Result<()> {
        let ok =
            unsafe { (rt().api.set_block)(self.dim, self.x, self.y, self.z, crate::ffi::s(spec)) };
        if ok {
            Ok(())
        } else {
            Err(Error(format!("set_block failed for spec '{spec}'")))
        }
    }
}
