use crate::error::Error;
use crate::ffi::s;
use crate::player::Player;
use crate::sys;

#[derive(Debug, Clone)]
enum Target {
    PlayerInventory(Player),
    PlayerEnderChest(Player),
    PlayerArmor(Player),
    PlayerHands(Player),
    Block { dim: i32, x: i32, y: i32, z: i32 },
}

#[derive(Debug, Clone)]
pub struct Container {
    target: Target,
}

mod ops;

impl Container {
    pub(crate) fn player_inventory(player: Player) -> Container {
        Container {
            target: Target::PlayerInventory(player),
        }
    }

    pub(crate) fn player_ender_chest(player: Player) -> Container {
        Container {
            target: Target::PlayerEnderChest(player),
        }
    }

    pub(crate) fn player_armor(player: Player) -> Container {
        Container {
            target: Target::PlayerArmor(player),
        }
    }

    pub(crate) fn player_hands(player: Player) -> Container {
        Container {
            target: Target::PlayerHands(player),
        }
    }

    fn ffi_ref(&self) -> sys::LeviRsContainerRef {
        let empty = sys::LeviRsPlayerSel {
            kind: 0,
            value: s(""),
        };
        match &self.target {
            Target::PlayerInventory(p) => sys::LeviRsContainerRef {
                which: 0,
                player: p.ffi_sel(),
                dim: 0,
                x: 0,
                y: 0,
                z: 0,
            },
            Target::PlayerEnderChest(p) => sys::LeviRsContainerRef {
                which: 1,
                player: p.ffi_sel(),
                dim: 0,
                x: 0,
                y: 0,
                z: 0,
            },
            Target::PlayerArmor(p) => sys::LeviRsContainerRef {
                which: 2,
                player: p.ffi_sel(),
                dim: 0,
                x: 0,
                y: 0,
                z: 0,
            },
            Target::PlayerHands(p) => sys::LeviRsContainerRef {
                which: 3,
                player: p.ffi_sel(),
                dim: 0,
                x: 0,
                y: 0,
                z: 0,
            },
            Target::Block { dim, x, y, z } => sys::LeviRsContainerRef {
                which: 4,
                player: empty,
                dim: *dim,
                x: *x,
                y: *y,
                z: *z,
            },
        }
    }

    fn gone(&self) -> Error {
        Error("container unreachable (player offline / block has no container)".into())
    }
}
